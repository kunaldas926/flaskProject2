<!--
title: 'flaskProject2'
description: 'This example demonstrates how to setup a RESTful Web Service allowing you to create, list, get, update and delete Todos. DynamoDB is used to store the data.'
layout: Doc
framework: v0.0.1
platform: AWS
language: Python
priority: 10
authorLink: 'https://github.com/kunaldas926'
authorName: 'Kunal Das'
authorAvatar: 'https://avatars.githubusercontent.com/u/53109330?v=4'
-->
# flaskProject2